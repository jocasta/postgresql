#!/usr/bin/env bash
set -euo pipefail

###############################################################################
## Load environment
###############################################################################
ENV_FILE=".postgres.env"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: $ENV_FILE not found."
  exit 1
fi

set -o allexport
source "$ENV_FILE"
set +o allexport

###############################################################################
## Validate required variables
###############################################################################
REQUIRED_VARS=(
  PG_VERSION
  CONTAINER_NAME
  HOST_PORT
  DATA_VOLUME
  DB_USER
  DB_PASSWORD
  DB_NAME
)

for var in "${REQUIRED_VARS[@]}"; do
  if [[ -z "${!var:-}" ]]; then
    echo "ERROR: Environment variable '$var' is not set."
    exit 1
  fi
done

###############################################################################
## Derived values
###############################################################################
IMAGE="local-postgres:${PG_VERSION}"
CONF_FILE="./postgresql.conf"
LOGS_DIR="./logs"

CONF_IN_CONTAINER="/etc/postgresql/postgresql.conf"
LOGS_IN_CONTAINER="/var/log/postgresql"
DATA_IN_CONTAINER="/var/lib/postgresql"

###############################################################################
## Prep filesystem
###############################################################################
echo "[INFO] Ensuring logs directory exists..."
mkdir -p "$LOGS_DIR"
chmod -R 0777 "$LOGS_DIR" 2>/dev/null || true

if [[ ! -f "$CONF_FILE" ]]; then
  echo "ERROR: $CONF_FILE not found."
  exit 1
fi

###############################################################################
## Build custom image (pg_cron included)
###############################################################################
echo "[INFO] Building Postgres image with pg_cron..."
docker build \
  --build-arg PG_VERSION="$PG_VERSION" \
  -t "$IMAGE" .

###############################################################################
## Remove existing container if image changed
###############################################################################
if docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
  CURRENT_IMAGE="$(docker inspect -f '{{.Config.Image}}' "$CONTAINER_NAME")"
  if [[ "$CURRENT_IMAGE" != "$IMAGE" ]]; then
    echo "[INFO] Existing container uses $CURRENT_IMAGE, recreating..."
    docker rm -f "$CONTAINER_NAME" >/dev/null
  else
    echo "[INFO] Container exists and image matches; restarting..."
    docker restart "$CONTAINER_NAME" >/dev/null
    docker ps --filter "name=^/${CONTAINER_NAME}$"
    exit 0
  fi
fi

###############################################################################
## Start container
###############################################################################
echo "[INFO] Starting container '$CONTAINER_NAME'..."

docker run -d \
  --name "$CONTAINER_NAME" \
  -e POSTGRES_USER="$DB_USER" \
  -e POSTGRES_PASSWORD="$DB_PASSWORD" \
  -e POSTGRES_DB="$DB_NAME" \
  -p "${HOST_PORT}:5432" \
  -v "${DATA_VOLUME}:${DATA_IN_CONTAINER}" \
  -v "$(pwd)/${LOGS_DIR}:${LOGS_IN_CONTAINER}:Z" \
  -v "$(pwd)/${CONF_FILE}:${CONF_IN_CONTAINER}:ro" \
  "$IMAGE" \
  postgres -c "config_file=${CONF_IN_CONTAINER}" >/dev/null

echo "[INFO] Container started."

###############################################################################
## Create monitoring users (unchanged behavior)
###############################################################################
echo "[INFO] Waiting for Postgres to accept connections..."
until docker exec "$CONTAINER_NAME" pg_isready -U "$DB_USER" -d "$DB_NAME" >/dev/null 2>&1; do
  sleep 1
done

echo "[INFO] Ensuring monitoring users exist..."
docker exec -i "$CONTAINER_NAME" \
  psql -v ON_ERROR_STOP=1 -U "$DB_USER" -d "$DB_NAME" <<'SQL'
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'dd_monitoring_migrations') THEN
    CREATE ROLE dd_monitoring_migrations LOGIN SUPERUSER PASSWORD 'test';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'dd_monitoring_writer') THEN
    CREATE ROLE dd_monitoring_writer LOGIN PASSWORD 'test';
  END IF;
END$$;
SQL

echo
echo "Connect:"
echo "  psql -h localhost -p ${HOST_PORT} -U ${DB_USER} -d ${DB_NAME}"
echo
echo "Now Run flyway to setup your dev env:"
echo
echo "  $ flyway migrate"
echo "  $ flyway -configFiles=flyway_postgres.conf migrate"
echo
echo "Tail logs:"
echo "  docker logs -f ${CONTAINER_NAME}"
echo