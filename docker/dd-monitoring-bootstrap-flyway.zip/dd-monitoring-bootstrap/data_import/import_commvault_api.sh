#!/usr/bin/env bash
set -euo pipefail

# ---- CONFIG --------------------------------------------------------

SOURCE_HOST="dd-monitoring.cluster-cr4aco8o6rxb.eu-west-2.rds.amazonaws.com"
SOURCE_PORT=5432
SOURCE_DB="dd_monitoring"
SOURCE_USER="dd_monitoring_admin"

TARGET_HOST="localhost"
TARGET_PORT=5432
TARGET_DB="dd_monitoring"
TARGET_USER="test"

TABLE="commvault.api_responses"

# -------------------------------------------------------------------

echo "[INFO] Testing passwordless access (source)..."
if ! PGPASSWORD= psql \
  -h "$SOURCE_HOST" -p "$SOURCE_PORT" \
  -U "$SOURCE_USER" -d "$SOURCE_DB" \
  -c "SELECT 1" >/dev/null 2>&1; then
  echo "[ERROR] Cannot connect to source DB without password."
  echo "        Check ~/.pgpass for $SOURCE_HOST"
  exit 1
fi

echo "[INFO] Testing passwordless access (target)..."
if ! PGPASSWORD= psql \
  -h "$TARGET_HOST" -p "$TARGET_PORT" \
  -U "$TARGET_USER" -d "$TARGET_DB" \
  -c "SELECT 1" >/dev/null 2>&1; then
  echo "[ERROR] Cannot connect to target DB without password."
  echo "        Check ~/.pgpass for $TARGET_HOST"
  exit 1
fi

echo "[INFO] Passwordless access confirmed."

echo "[INFO] Importing table '$TABLE'..."
pg_dump \
  -h "$SOURCE_HOST" -p "$SOURCE_PORT" \
  -U "$SOURCE_USER" \
  -d "$SOURCE_DB" \
  --data-only \
  --table="$TABLE" \
  --disable-triggers \
| psql \
  -h "$TARGET_HOST" -p "$TARGET_PORT" \
  -U "$TARGET_USER" \
  -d "$TARGET_DB"

echo "[INFO] Import completed successfully."
