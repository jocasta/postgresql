#!/bin/bash

set -euo pipefail

## Assume Role
CREDENTIALS=$(aws sts assume-role \
   --role-arn arn:aws:iam::730335381548:role/dd-monitoring-dd_monitoring_migrations-IAM-AccessRole \
   --role-session-name test-db-access)

## Flip AWS Credentials
AWS_ACCESS_KEY_ID=$(echo ${CREDENTIALS} | jq -r '.Credentials.AccessKeyId')
 export AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=$(echo ${CREDENTIALS} | jq -r '.Credentials.SecretAccessKey')
 export AWS_SECRET_ACCESS_KEY
AWS_SESSION_TOKEN=$(echo ${CREDENTIALS} | jq -r '.Credentials.SessionToken')
 export AWS_SESSION_TOKEN
AWS_EXPIRATION=$(echo ${CREDENTIALS} | jq -r '.Credentials.Expiration')
 export AWS_EXPIRATION

## Display Assumed Role
echo ""
aws sts get-caller-identity | jq


# Use or Replace Cert Bundle
if [ -f /tmp/eu-west-2-bundle.pem ]; then
 echo -e  "\nReusing existing certificate file /tmp/eu-west-2-bundle.pem \n"
else
 wget -O /tmp/eu-west-2-bundle.pem https://truststore.pki.rds.amazonaws.com/eu-west-2/eu-west-2-bundle.pem
fi

## DB Credentials
DBHOST=dd-monitoring.cluster-cr4aco8o6rxb.eu-west-2.rds.amazonaws.com
DATABASE_NAME=dd_monitoring
DATABASE_USER=dd_monitoring_migrations
PORT=5432

## Get Auth-Token
PGPASSWORD="$(aws rds generate-db-auth-token \
    --region eu-west-2 \
    --hostname ${DBHOST} \
    --port $PORT \
    --username ${DATABASE_USER} )"

## DB Connection
psql "host=${DBHOST} \
      port=$PORT \
      sslmode=verify-full \
      sslrootcert=/tmp/eu-west-2-bundle.pem \
      dbname=${DATABASE_NAME} \
      user=${DATABASE_USER} \
      password=${PGPASSWORD}"