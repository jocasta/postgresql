SELECT cron.schedule_in_database(
 job_name => 'cleanup_api_responses_older_than_3_months',
 schedule => '0 2 * * *',
 database => 'dd_monitoring',
 command  => $$
 DELETE FROM commvault.api_responses
 WHERE inserted_at < now() - interval '3 months';
 $$
);