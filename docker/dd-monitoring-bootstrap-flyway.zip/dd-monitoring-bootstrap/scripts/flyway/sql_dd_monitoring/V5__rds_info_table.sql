
-- =========================
-- Function
-- =========================
-- Wrapper to allow use in generated column (must be IMMUTABLE)
CREATE OR REPLACE FUNCTION rds.base64_to_jsonb(input text)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
    SELECT convert_from(decode(input, 'base64'), 'UTF8')::jsonb;
$$;

-- =========================
-- Table
-- =========================
CREATE TABLE rds.rds_info (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account text NOT NULL,
    stage text NOT NULL,
    commit_hash text NOT NULL,
    cluster_identifier text NOT NULL,
    source_type text NOT NULL,

    -- Base64 encoded payload
    payload text NOT NULL,

    -- Generated JSONB (derived automatically)
    payload_json jsonb GENERATED ALWAYS AS (
        rds.base64_to_jsonb(payload)
    ) STORED,

    source_timestamp timestamptz NOT NULL,
    inserted_at timestamptz NOT NULL DEFAULT now()
);

-- =========================
-- Indexes
-- =========================

-- Fast retrieval of newest records
CREATE INDEX ix_rds_info_inserted_at_desc
ON rds.rds_info (inserted_at DESC);

-- JSONB search index
CREATE INDEX ix_rds_payload_json_gin
ON rds.rds_info USING gin (payload_json);

-- Optional but commonly useful indexes

CREATE INDEX ix_rds_info_cluster_identifier
ON rds.rds_info (cluster_identifier);

CREATE INDEX ix_rds_info_source_timestamp
ON rds.rds_info (source_timestamp);
