#!/usr/bin/env bash
set -euo pipefail

## Assume Role
CREDENTIALS=$(aws sts assume-role \
   --role-arn arn:aws:iam::730335381548:role/dd-monitoring-dd_monitoring_migrations-IAM-AccessRole \
   --role-session-name dd-monitoring-migrations-access)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

AWS_ACCESS_KEY_ID=$(echo ${CREDENTIALS} | jq -r '.Credentials.AccessKeyId')
export AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=$(echo ${CREDENTIALS} | jq -r '.Credentials.SecretAccessKey')
export AWS_SECRET_ACCESS_KEY
AWS_SESSION_TOKEN=$(echo ${CREDENTIALS} | jq -r '.Credentials.SessionToken')
export AWS_SESSION_TOKEN
AWS_EXPIRATION=$(echo ${CREDENTIALS} | jq -r '.Credentials.Expiration')
export AWS_EXPIRATION

# Print role
echo ""
aws sts get-caller-identity | jq


aws ssm get-parameter \
  --name "/RoS/CE/certs-bundle/rds-ca-eu-west-2-bundle" \
  --query "Parameter.Value" \
  --output text > /tmp/eu-west-2-bundle.pem

# cat /tmp/eu-west-2-bundle.pem

DBHOST=$(aws ssm get-parameter \
  --name "/ros/dd/aurora/dd-monitoring/database-endpoint" \
  --with-decryption \
  --query "Parameter.Value" \
  --output text)

echo "DBHOST: $DBHOST"

DATABASE_USER=dd_monitoring_migrations
PORT=5432

cat > "$CI_PROJECT_DIR/flyway_dd_monitoring.conf" <<EOF
flyway.url=jdbc:postgresql://${DBHOST}:5432/dd_monitoring?sslmode=require&sslrootcert=/tmp/eu-west-2-bundle.pem
flyway.user=${DATABASE_USER}
flyway.locations=filesystem:${CI_PROJECT_DIR}/scripts/flyway/sql_dd_monitoring
flyway.schemas=flyway
flyway.table=flyway_schema_history
flyway.createSchemas=true
flyway.validateOnMigrate=true
flyway.outOfOrder=false
flyway.connectRetries=5
flyway.cleanDisabled=true
EOF



cat > "$CI_PROJECT_DIR/flyway_postgres.conf" <<EOF
flyway.url=jdbc:postgresql://${DBHOST}:5432/postgres?sslmode=require&sslrootcert=/tmp/eu-west-2-bundle.pem
flyway.user=${DATABASE_USER}
flyway.locations=filesystem:${CI_PROJECT_DIR}/scripts/flyway/sql_postgres
flyway.schemas=flyway
flyway.table=flyway_schema_history
flyway.createSchemas=true
flyway.validateOnMigrate=true
flyway.outOfOrder=false
flyway.connectRetries=5
flyway.cleanDisabled=true
EOF

echo "Listing files in CI project directory:"
tree -L 4 "$CI_PROJECT_DIR"


export FLYWAY_PASSWORD="$(aws rds generate-db-auth-token \
  --region eu-west-2 \
  --hostname ${DBHOST} \
  --port ${PORT} \
  --username ${DATABASE_USER})"

echo "FLYWAY_PASSWORD: $FLYWAY_PASSWORD"

echo ""

flyway -configFiles=flyway_dd_monitoring.conf info

echo ""

flyway -configFiles=flyway_postgres.conf info
