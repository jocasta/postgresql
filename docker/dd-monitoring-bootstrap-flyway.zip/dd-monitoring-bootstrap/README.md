# dd-monitoring-bootstrap

Flyway migration project for the `dd-monitoring` Aurora PostgreSQL database. Migrations are developed and tested locally against a Docker Postgres container, then applied to Aurora automatically when changes are merged to `master`.

---

## Overview

There are two independent Flyway migration tracks, each targeting a different database:

| Track | Config file | SQL directory | Target database |
|---|---|---|---|
| `dd_monitoring` | `flyway.conf` | `scripts/flyway/sql_dd_monitoring/` | Application schemas and tables |
| `postgres` | `flyway_postgres.conf` | `scripts/flyway/sql_postgres/` | pg_cron extension and scheduled jobs |

Both tracks maintain their migration history in a `flyway` schema within their respective databases.

---

## Prerequisites

- Docker
- [Flyway CLI](https://flywaydb.org/documentation/usage/commandline/) installed and on your `PATH`
- AWS CLI (for connecting to Aurora directly via `dd_migrations_connect.sh`)

---

## Local Development

### 1. Start the Postgres container

```bash
./postgres_start_container.sh
```

This script:
- Builds a local `postgres:16.*` image with the `pg_cron` extension added
- Starts a Docker container named `postgres16` on port `5432`
- Mounts a named volume (`pg16_data`) for data persistence and `./logs` for PostgreSQL logs
- Waits for the container to be ready, then creates two roles:
  - `dd_monitoring_migrations` — superuser (used by Flyway)
  - `dd_monitoring_writer` — restricted write access (used by applications)

The container configuration (port, credentials, etc.) is controlled by `.postgres.env`.

### 2. Run Flyway migrations

Run migrations against the `dd_monitoring` database:

```bash
flyway -configFiles=flyway.conf migrate
```

Run migrations against the `postgres` database (pg_cron setup):

```bash
flyway -configFiles=flyway_postgres.conf migrate
```

Check migration status without applying changes:

```bash
flyway -configFiles=flyway.conf info
flyway -configFiles=flyway_postgres.conf info
```

### 3. Connect to the local database

```bash
psql -h localhost -p 5432 -U test -d dd_monitoring
```

### 4. Stop or destroy the container

Stop the container (preserves data volume):

```bash
./postgres_stop_container.sh
```

Destroy the container, volume, logs, and images (full reset):

```bash
./postgres_destroy_container.sh
```

---

## Writing Migrations

SQL migration files follow Flyway's standard versioned naming convention:

```
V{version}__{description}.sql
```

- Add `dd_monitoring` database migrations to `scripts/flyway/sql_dd_monitoring/`
- Add `postgres` database migrations (pg_cron jobs, extensions) to `scripts/flyway/sql_postgres/`

Version numbers must be sequential and never reused. Once a migration has been applied (locally or in Aurora) its file must not be modified — Flyway validates checksums and will fail if a previously applied file has changed.

### Current schemas in `dd_monitoring`

| Schema | Purpose |
|---|---|
| `cur_reports` | AWS Cost and Usage Report data |
| `commvault` | Commvault backup monitoring (API response storage) |
| `rds` | RDS instance inventory (base64-encoded JSON payloads) |

A scheduled pg_cron job (defined in `sql_postgres/V3`) deletes `commvault.api_responses` rows older than 3 months, running daily at 02:00 UTC.

---

## What Happens When Code is Merged

The GitLab CI pipeline (`.gitlab-ci.yml`) runs two stages automatically on push:

### Stage 1: `flyway_info` — runs on every branch push

The `scripts/flyway-info.sh` script:
1. Assumes the IAM role `dd-monitoring-dd_monitoring_migrations-IAM-AccessRole`
2. Fetches the RDS CA certificate bundle from AWS SSM
3. Fetches the Aurora cluster endpoint from AWS SSM
4. Generates two Flyway config files (`flyway_dd_monitoring.conf`, `flyway_postgres.conf`) using an IAM auth token as the password — no static credentials are used
5. Runs `flyway info` against both databases and outputs the pending/applied migration status

These config files are saved as CI job artifacts for the next stage.

### Stage 2: `flyway_migrate` — runs only on merge to `master`

The `scripts/flyway-migrate.sh` script:
1. Repeats the IAM role assumption and token generation
2. Reads the config files produced by the `flyway_info` artifact
3. Runs `flyway migrate` then `flyway info` against `flyway_dd_monitoring.conf`
4. Runs `flyway migrate` then `flyway info` against `flyway_postgres.conf`

Migrations are applied to the live Aurora cluster. `flyway.cleanDisabled=true` is enforced in CI — the `clean` command cannot be run against Aurora.

### Pipeline summary

```
branch push  →  flyway_info  (all branches — shows pending migrations)
                     │
merge to master  →  flyway_migrate  (master only — applies migrations to Aurora)
```

---

## Connecting to Aurora Directly

To open a psql session against the live Aurora cluster (requires AWS credentials and appropriate IAM permissions):

```bash
./dd_migrations_connect.sh
```

This script assumes the required IAM role, fetches the RDS CA bundle, generates an auth token, and connects with `sslmode=verify-full`.

---

## Importing Production Data Locally

To copy `commvault.api_responses` data from Aurora into your local container:

```bash
./data_import/import_commvault_api.sh
```

Requires a `~/.pgpass` entry for the Aurora host. The script tests connectivity to both Aurora and localhost before proceeding.

---

## Local Environment Variables

`.postgres.env` controls the local Docker container:

| Variable | Default | Purpose |
|---|---|---|
| `PG_VERSION` | `16.*` | Postgres version |
| `CONTAINER_NAME` | `postgres16` | Docker container name |
| `HOST_PORT` | `5432` | Port exposed on localhost |
| `DATA_VOLUME` | `pg16_data` | Named Docker volume for data |
| `DB_USER` | `test` | Superuser for container management |
| `DB_PASSWORD` | `test` | Superuser password |
| `DB_NAME` | `dd_monitoring` | Default database created on init |
